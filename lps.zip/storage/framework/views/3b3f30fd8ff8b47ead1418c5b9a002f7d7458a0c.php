<div class="header_box" style="
    height: 100px;
">

<div class="container">
    <div class="inner_section">
        <div class="row">
            <div class=" column  pull-left">      
                <div class=" delay-01s animated fadeInDown wow animated">
                <h3>Google Translator</h3>
                    <form action="https://translate.google.com.ua/m/translate?hl=uk" method="get" target="_blank" placeholder="Search the word...">
                    <input name="q" type="text"/>
                    <br/>
                    <input type="submit" value="Google Translator Search"/>
                    </form>
                </div>
            </div>
            <div class=" column pull-right">
                <div class=" delay-01s animated fadeInDown wow animated">
         
                         <script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
                         <div class=" scype animated bounceIn wow delay-02s" id="SkypeButton_Call_innadanylevska_1"><a href="javascript:void(0)">
<script type="text/javascript">
 Skype.ui({
 "name": "chat",
 "element": "SkypeButton_Call_innadanylevska_1",
 "participants": ["innadanylevska"],
 "imageSize": 32
 });
 </script>
                            </a></div>
                </div>
            </div>    
 
      
        </div>
    </div>      
</div>
</div>



     
