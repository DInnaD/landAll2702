    
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
               
                    <div class="panel-heading">Portfolios</div>

                    <div class="panel-body">
                        <?php echo e(link_to_route('admin', 'admin', null, ['class' => 'btn btn-info btn-xs'])); ?>

                        <?php echo e(link_to_route('portfolios.create', 'create', null, ['class' => 'btn btn-info btn-xs'])); ?>


                        <hr>
                        <table class="table table-bordered table-responsive table-striped">
                            <tr>
                            
                                <th width="5%">id</th>
                                <th width="15%">Name</th>
                                <th width="15%">Filter</th>
                                <th width="15%">Link</th>
                                <th width="20%">Images</th>                                
                                <th width="25%">Actions</th>
                            </tr>
                            <tr>
                            
                                <td colspan="6" class="light-green-background no-padding" title="Create new template">
                                    <div class="row centered-child">
                                        <div class="col-md-12">

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        
                        
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                             
                                <td><?php echo e($model->id); ?></td>
                                <td><?php echo e($model->name); ?></td>
                                <td><?php echo e($model->filter); ?></td>
                                <td><?php echo e($model->link); ?></td>       
                                <td><?php echo e($model->images); ?></td>
                                
                                
                                <!--??????????????????????????_templates-->
                                <td>
                                    <?php echo e(Form::open(['class' => 'confirm-delete', 'route' => ['portfolios.destroy', $model->id], 'method' => 'DELETE'])); ?>

                                    <?php echo e(link_to_route('pages.index', 'TOPIC', [$model->id], ['class' => 'btn btn-success btn-xs'])); ?>

                                    <?php echo e(link_to_route('portfolios.show', 'info', [$model->id], ['class' => 'btn btn-info btn-xs'])); ?>

                                    <?php echo e(link_to_route('portfolios.edit', 'edit', [$model->id], ['class' => 'btn btn-success btn-xs'])); ?>

                                    
                                    <?php echo e(Form::button('Delete', ['class' => 'btn btn-danger btn-xs', 'type' => 'submit'])); ?>

                                    <?php echo e(Form::close()); ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                        <div class="text-center">
                            { !! $portfolios->render() !!}

                        </div>
                   
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>