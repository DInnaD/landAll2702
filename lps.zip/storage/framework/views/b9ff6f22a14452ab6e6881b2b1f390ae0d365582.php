


          
        

<!--Service-->

<?php if(isset($portfolios) && is_object($portfolios)): ?>
       
 <?php if(isset($pages) && is_object($pages)): ?>      
<!-- Portfolio -->
<section id="Portfolio" class="content"> 
  
  <!-- Container -->
  <div class="container portfolio_title"> 
    
    <!-- Title -->
    <div class="section-title">
    <h2><?php echo e(link_to_route('portfolios.index', 'LandingPages')); ?></h2>
    </div>

    <!--/Title --> 
    
  </div>
  <!-- Container -->
  
  <div class="portfolio-top"></div>
  
  <!-- Portfolio Filters tags  -->
  <div class="portfolio"> 
   <?php if(isset($tags)): ?>
       
    <div id="filters" class="sixteen columns">
      <ul class="clearfix">
        <li><a id="all" href="#" data-filter="*" class="active">
          <h5>All</h5>
          </a></li>
          <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><a class="" href="" data-filter=".<?php echo e($tag); ?>">
          <h5><?php echo e($tag); ?></h5>
          </a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        
        
      </ul>
    </div>
    <!--/Portfolio Filters --> 
  <?php endif; ?>  
    <!-- Portfolio Wrapper -->
    <div class="isotope fadeInLeft animated wow" style="position: relative; overflow: hidden; height: 480px;" id="portfolio_wrapper"> 
       <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <!-- Portfolio Item -->
      <div style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1); width: 337px; opacity: 1;" class="portfolio-item one-four   <?php echo e($item->filter); ?> isotope-item">
        <div class="portfolio_img"> 
        <?php echo Html::image('assets/img/'.$item->images,$item->name); ?>

        </div>        
        <div class="item_overlay">
          <div class="item_info">
            <a class="" href="<?php echo e(route('topic', compact('item'))); ?>" target="_blank"><i class="fa fa-info-circle" style = "font-size: 120px; padding-bottom: 0px;"></i></a> 
            <a class="" href="<?php echo e($item->link); ?>" target="_blank"><i class="fa fa-facebook" style = "font-size: 40px; padding-bottom: 0px; "></i></a>
            <h4 class="project_name" style = "padding-top: 0px;"><?php echo e($item->name); ?></h4>


          </div>
        </div>
        </div>
  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

      <!--/Portfolio Item  -->
      
    </div>
    <!--/Portfolio Wrapper --> 
    
  </div>
  <!--/Portfolio Filters -->
  
  <div class="portfolio_btm"></div>
  
  
  <div id="project_container">
    <div class="clear"></div>
    <div id="project_data"></div>

   
  </div>
 
  
</section>
<?php endif; ?> 
<?php endif; ?> 
<!--/Portfolio --> 
<!--Service-->
<section  id="service">
  <div class="container">
    <h2>INSTRUCTION</h2>
    <div class="service_wrapper">
    
      <?php if(isset($services) && is_object($services)): ?>
      
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    

        <?php if($service->id == 0 || $service->id%3 == 0): ?>
      <div class="row" <?php echo e(($service->id != 0) ? 'borderTop' : ''); ?>>
      
        <?php endif; ?>

        <div class="col-lg-4" <?php echo e(($service->id%3 > 0) ? 'borderLeft' : ''); ?> <?php echo e(($service->id > 2) ? 'mrgTop' : ''); ?>>
          <div class="service_block">
            <div class="service_icon delay-03s animated wow  zoomIn"> <span><i class="fa <?php echo e($service->icon); ?>"></i></span> </div>
            <h3 class="animated fadeInUp wow"><?php echo e($service->name); ?></h3>
            <p class="animated fadeInDown wow"><?php echo e($service->text); ?></p>
          </div>
        </div>


        <?php if(($service->id + 1)%3 == 0): ?>
          </div>
        <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
    </div>
  </div>
</section>

 <?php endif; ?>
        
          
        

<!--Service-->
<!--client_logos-->
<?php if(isset($peoples) && is_object($peoples)): ?>
<section class="page_section team" id="team"><!--main-section team-start-->
  <div class="container">
    <h2><?php echo e(link_to_route('peoples.index', 'TEAM')); ?></h2>
    
    <div class="team_section clearfix">
    <?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $people): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      
      <div class="team_area">
        <div class="team_box wow fadeInDown delay-0<?php echo e(($people->id*3 + 3)); ?>s">
        
          <div class="team_box_shadow"><a href="javascript:void(0)"></a></div>
          <?php echo Html::image('assets/img/'.$people->images,$people->name); ?>

          <ul>
          <?php if(isset($socialPeoples) && is_object($socialPeoples)): ?>
             <?php $__currentLoopData = $people->socialPeoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialPeople): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="twitter animated bounceIn wow delay-02s"><a href="<?php echo e($socialPeople->link); ?>" target="_blank"><i class="fa <?php echo e($socialPeople->callBack); ?>"></i></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>  
          </ul>
        </div>
        <h3 class="wow fadeInDown delay-0<?php echo e(($people->id*3 + 3)); ?>s"><?php echo e($people->name); ?></h3>
        <span class="wow fadeInDown delay-0<?php echo e(($people->id*3 + 3)); ?>s"><?php echo e($people->position); ?></span>
        <p class="wow fadeInDown delay-0<?php echo e(($people->id*3 + 3)); ?>s"><?php echo e($people->text); ?></p>
      </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

      
      
    </div>
  </div>
</section>
<!--/Team-->
<!--Footer-->
<footer class="footer_wrapper" id="contact">
  
  <div class="container">
    <div class="footer_bottom"><span>Copyright © 2018,    Create by <a href="https://www.facebook.com/ITvolunteerInnaDanylevska">ITvolunteersFIRST</a>. </span> </div>


  </div>
</footer>
