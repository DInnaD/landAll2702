<div class="form-group">
	
    
    <?php echo Form::label('old_images', 'Image'); ?>	
    <?php echo Html::image('assets/img/'.$people['images']); ?>

    <?php echo Form::hidden('old_images', $people['images'], ['class' => 'form-control', 'filestyle', 'data-buttonText'=>'Chose image']); ?>

    	
    
</div>

