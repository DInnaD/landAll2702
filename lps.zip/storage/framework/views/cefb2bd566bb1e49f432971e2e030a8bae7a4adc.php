<div class="form-group">
	<?php echo Form::label('name', 'Name'); ?>	
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('filter', 'Filter'); ?>

    <?php echo Form::text('filter', null, ['class' => 'form-control']); ?>    
    
    <?php echo Form::label('images', 'Image'); ?>

    <?php echo Form::file('images', null, ['class' => 'form-control']); ?>

</div>

