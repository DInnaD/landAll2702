<div class="form-group">
	<?php echo Form::label('name', 'Name'); ?>	
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('link', 'Link'); ?>

    <?php echo Form::text('link', null, ['class' => 'form-control']); ?> 
    <?php echo Form::label('callBack', 'Icon'); ?>

    <?php echo Form::text('callBack', null, ['class' => 'form-control']); ?>    
    
</div>

