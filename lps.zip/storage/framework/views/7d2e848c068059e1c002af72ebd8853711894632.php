
<section><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><?php echo e($page->name); ?></h2>
    <div class="inner_section">
    <div class="row">
      <div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
      <?php echo Html::image('assets/img/'.$page->audios,'',['class' => 'izoomIn wow animated']); ?>

      </div>
        <div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
            <div class=" delay-01s animated fadeInDown wow animated">
                      
            
              <?php echo Html::image('assets/img/'.$page->videos,'',['class' => 'zoomIn wow animated']); ?>

              
              
</div>
       
       </div>
        
      </div>
      <?php echo link_to(route('topic'),'Back'); ?>

      
    </div>
  </div> 
  </div>
</section>





        
          
        

