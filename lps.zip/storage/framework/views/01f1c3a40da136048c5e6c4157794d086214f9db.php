<div class="form-group">
	
    
    <?php echo Form::label('old_images', 'Image'); ?>	
    <?php echo Html::image('assets/img/'.$page['images']); ?>

    <?php echo Form::hidden('old_images', $page['images'], ['file'=>'true','class' => 'form-control', 'filestyle', 'data-buttonText'=>'Chose immage', 'enctype'=>'multipart/form-data']); ?>

    	
    
</div>

