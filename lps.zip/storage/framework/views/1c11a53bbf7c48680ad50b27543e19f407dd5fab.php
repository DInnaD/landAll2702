

<div class="header_box" style="
    height: 100px;
">
<div class=" delay-01s animated fadeInDown wow animated">

  <div class="flex-center position-ref full-height">



       
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <ul class="social_links">
                    <?php if(auth()->guard()->check()): ?>
                        
                        

                        <li class="pinterest animated bounceIn wow delay-01s"><a href="<?php echo e(url('/admin')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        
                        <li class="pinterest animated bounceIn wow delay-02s">
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out " style="color:red"></i>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                  
                    <?php if(isset($socialAlls) && is_object($socialAlls)): ?>
                    <?php $__currentLoopData = $page->socialAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                                    
                        <li class="gplus animated bounceIn wow delay-02s" target="_blank"><a href="<?php echo e($socialAll->link); ?>" target="_blank"><i class="fa <?php echo e($socialAll->callBack); ?>"></i></a></li>

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php else: ?>
                        
                       
                        <li class="pinterest animated bounceIn wow delay-01s"><a href=" <?php echo e(route('login')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        <li class="twitter animated bounceIn wow delay-02s"><a href="<?php echo e(route('register')); ?> "><i class="far fa-registerd" ></i></a></li>

                    <?php if(isset($socialAlls) && is_object($socialAlls)): ?>
                    <?php $__currentLoopData = $page->socialAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                    

                        <li class="gplus animated bounceIn wow delay-02s" target="_blank"><a href="<?php echo e($socialAll->link); ?>" target="_blank"><i class="fa <?php echo e($socialAll->callBack); ?>"></i></a></li>
                        
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                    
                    <?php endif; ?>
                </div>

            <?php endif; ?>

 </div>
</div> 
     




     
