<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('site.content_portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>