<div class="form-group">
	   
    
    <?php echo Form::label('old_images', 'Image'); ?>	
    <?php echo Html::image('assets/img/'.$logo['images']); ?>

    <?php echo Form::hidden('old_images', $logo['images'], ['class' => 'form-control', 'filestyle', 'data-buttonText'=>'Chose Logo']); ?>

    	
    
    	
    
</div>

