<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e(config('app.name', 'CopyBook')); ?></title>

<?php if(isset($logos) && is_object($logos)): ?>
<?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
       
<!--title></title-->
    
<link rel="icon" href="<?php echo e('assets/img/'.$logo->images); ?>" type="image/png">  
                   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<!--link rel="icon" href="<?php echo e(asset('assets/favicon.png')); ?>" type="image/png"--> 
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css"> 
<link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css"> 
<link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css">

<!--script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script-->
 
<!--[if lt IE 9]>
    <script src="js/respond-1.1.0.min.js"></script>
    <script src="js/html5shiv.js"></script>
    <script src="js/html5element.js"></script>
<![endif]-->

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

 

    </head>
    <body>
        <div class="flex-center position-ref full-height">



       
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <ul class="social_links">
                    <?php if(auth()->guard()->check()): ?>
                        
                        <li class="twitter animated bounceIn wow delay-02s"><a href="https://hangouts.google.com/group/sfBHtAbl4gOhltXH2"><i class="fa fa-google-plus"></i></a></li>
                        <li class="twitter animated bounceIn wow delay-02s"><a href="https://join.skype.com/eouNXEjbdzvC"><i class="fa fa-skype"></i></a></li>

                        <li class="pinterest animated bounceIn wow delay-01s"><a href="<?php echo e(url('/admin')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        
                        <li class="pinterest animated bounceIn wow delay-02s">
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out " style="color:red"></i>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                  
                    <?php if(isset($socials) && is_object($socials)): ?>
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                                    
                        <li class="gplus animated bounceIn wow delay-02s"><a href="<?php echo e($social->link); ?>"><i class="fa <?php echo e($social->callBack); ?>"></i></a></li>

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php else: ?>
                        
                        <li class="twitter animated bounceIn wow delay-02s"><a href="https://hangouts.google.com/group/sfBHtAbl4gOhltXH2"><i class="fa fa-google-plus"></i></a></li>
                        <li class="twitter animated bounceIn wow delay-02s"><a href="https://join.skype.com/eouNXEjbdzvC"><i class="fa fa-skype"></i></a></li>
                        <li class="pinterest animated bounceIn wow delay-01s"><a href=" <?php echo e(route('login')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        <li class="twitter animated bounceIn wow delay-02s"><a href="<?php echo e(route('register')); ?> "><i class="far fa-registerd" ></i></a></li>

                    <?php if(isset($socials) && is_object($socials)): ?>
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                    

                        <li class="gplus animated bounceIn wow delay-02s"><a href="<?php echo e($social->link); ?>"><i class="fa <?php echo e($social->callBack); ?>"></i></a></li>
                        
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                    
                    <?php endif; ?>
                </div>

            <?php endif; ?>

<div class="top-left links">
<div class="logo">
        
<?php if(isset($logos) && is_object($logos)): ?>
<?php $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <a href="<?php echo e(url ('/')); ?>"><?php echo Html::image('assets/img/'.$logo->images); ?></a>
          
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</div>
</div>
        <!--Header_section-->
<header id="header_wrapper">
  <?php echo $__env->yieldContent('header'); ?>

</header>
  
  <?php echo $__env->yieldContent('content'); ?>


<script src="<?php echo e(asset('/vendor/call-request/js/callrequest.js')); ?>"></script>.
    <link href="<?php echo e(asset('/vendor/call-request/css/callrequest.css')); ?>" rel='stylesheet' type='text/css'>
     
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-1.11.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-scrolltofixed.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.nav.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.isotope.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/wow.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    </body>
</html>
