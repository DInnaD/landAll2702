@extends('layouts.site')

@section('header')
	@include('site.header')
@endsection

@section('content')
	@include('admin.pages.content')
@endsection
