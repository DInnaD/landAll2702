@extends('layouts.site_page')


@section('content')
	@include('site.content_page1')
@endsection
